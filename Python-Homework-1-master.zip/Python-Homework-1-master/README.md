# Python-Homework-1
1st Python Homework for Fintech Bootcamp
